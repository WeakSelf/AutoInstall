typedef struct cast256_instance {
	word32 l_key[96];
} cast256_key;

